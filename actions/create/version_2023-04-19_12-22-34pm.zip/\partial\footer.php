<div id="main__footer">Powered by WSS</div>

<div class="modal fade" id="GeneralModal" aria-labelledby="GeneralModal" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="Title">...</h1>
        <button type="button" class="btn-close m-0" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="mcontent">
        ...
      </div>
    </div>
  </div>
</div>