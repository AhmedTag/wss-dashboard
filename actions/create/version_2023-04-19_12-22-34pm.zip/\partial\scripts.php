<script src="./library/jquery-3.6.1/jquery-3.6.1.min.js"></script>
<script src="./library/bootstrap-5.2.2/bootstrap.bundle.min.js"></script>
<script src="./library/slick-1.8.1/slick.min.js"></script>
<script src="./library/chosen-1.8.7/chosen.jquery.min.js"></script>
<script src="./library/sweetalert-2.0.0/swal.js"></script>
<script src="./library/jquery-3.6.1/jquery.zoom.min.js"></script>
<script src="./library/general/admin.js"></script>
