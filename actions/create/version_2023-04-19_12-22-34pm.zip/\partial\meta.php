  <title>WSS Control Panel</title>
  <meta charset="UTF-8">
  <meta name="description" content="Control Panel">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">