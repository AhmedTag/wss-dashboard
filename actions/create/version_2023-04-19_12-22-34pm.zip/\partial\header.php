<div class="row">
    <div class="col-12 col-md-3">
        <div id="logo">
            <img src="./images/general/logo-text.png" />
        </div>
    </div>
    <div class="col-12 col-md welcome">
        <span>أهلا <strong>المدير العام</strong></span>
    </div>
</div>